Demo video script (4-6 minutes):
1. Intro (20s): Your name, purpose of app.
2. Show signup & login (30s): create host account and guest account.
3. Host: create event (45s) — fill title, date/time, capacity.
4. Guest: view event & RSVP (45s).
5. Host: view attendee list & send reminder (30s).
6. Wrap up & future features (20s).
