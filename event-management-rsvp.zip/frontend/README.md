Frontend:
- Run: npm install && npm run dev
- Set VITE_API_BASE in .env
