import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import EventDetails from './pages/EventDetails'
import Login from './pages/Login'
import CreateEvent from './pages/CreateEvent'

function App(){
  return (
    <BrowserRouter>
      <div className="min-h-screen p-4">
        <header className="mb-6">
          <Link to="/" className="text-2xl font-bold">Event App</Link>
        </header>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/events/:id" element={<EventDetails/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/create" element={<CreateEvent/>} />
        </Routes>
      </div>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')).render(<App />)
