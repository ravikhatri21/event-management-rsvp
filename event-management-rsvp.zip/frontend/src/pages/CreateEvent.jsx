import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

export default function CreateEvent(){
  const [title,setTitle]=useState(''); const [starts,setStarts]=useState('');
  const nav = useNavigate()
  const submit = async (e) => {
    e.preventDefault()
    try {
      const token = localStorage.getItem('token')
      const payload = { title, starts_at: starts, description: '', capacity: 0, is_public: true }
      await axios.post(import.meta.env.VITE_API_BASE + '/events', payload, { headers: { Authorization: 'Bearer ' + token }})
      alert('Event created')
      nav('/')
    } catch (err) {
      alert(err.response?.data?.error || 'Failed')
    }
  }
  return (
    <form onSubmit={submit} className="max-w-lg">
      <h2 className="text-xl mb-3">Create Event</h2>
      <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" className="w-full p-2 border mb-2"/>
      <input value={starts} onChange={e=>setStarts(e.target.value)} placeholder="Starts at (YYYY-MM-DD HH:MM)" className="w-full p-2 border mb-2"/>
      <button className="px-3 py-2 bg-green-600 text-white rounded">Create</button>
    </form>
  )
}
