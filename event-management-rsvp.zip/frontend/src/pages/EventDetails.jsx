import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import axios from 'axios'

export default function EventDetails(){
  const { id } = useParams()
  const [event, setEvent] = useState(null)
  useEffect(()=> {
    axios.get(import.meta.env.VITE_API_BASE + '/events/' + id)
      .then(r=> setEvent(r.data))
      .catch(()=>{})
  },[id])
  const handleRsvp = async (status) => {
    try {
      const token = localStorage.getItem('token')
      await axios.post(import.meta.env.VITE_API_BASE + '/events/' + id + '/rsvp', { status }, { headers: { Authorization: 'Bearer ' + token }})
      alert('RSVP sent')
    } catch (err) {
      alert(err.response?.data?.error || 'Failed')
    }
  }
  if (!event) return <div>Loading...</div>
  return (
    <div>
      <h2 className="text-2xl">{event.title}</h2>
      <p>{event.description}</p>
      <p>Starts: {new Date(event.starts_at).toLocaleString()}</p>
      <div className="mt-4">
        <button onClick={()=>handleRsvp('confirmed')} className="px-3 py-2 bg-green-600 text-white rounded mr-2">RSVP</button>
        <button onClick={()=>handleRsvp('declined')} className="px-3 py-2 border rounded">Decline</button>
      </div>
    </div>
  )
}
