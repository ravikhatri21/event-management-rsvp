import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

export default function Home(){
  const [events, setEvents] = useState([])
  useEffect(()=> {
    axios.get(import.meta.env.VITE_API_BASE + '/events')
      .then(r=> setEvents(r.data))
      .catch(()=>{})
  },[])
  return (
    <div>
      <div className="mb-4">
        <Link to="/create" className="px-3 py-2 bg-blue-600 text-white rounded">Create Event</Link>
        <Link to="/login" className="ml-2 px-3 py-2 border rounded">Login</Link>
      </div>
      <h2 className="text-xl mb-3">Public Events</h2>
      <div className="grid gap-4">
        {events.map(e=>(
          <div key={e.id} className="p-4 border rounded">
            <h3 className="font-semibold">{e.title}</h3>
            <p>{new Date(e.starts_at).toLocaleString()}</p>
            <p>Host: {e.host_name}</p>
            <Link to={'/events/' + e.id} className="text-blue-600">View</Link>
          </div>
        ))}
      </div>
    </div>
  )
}
