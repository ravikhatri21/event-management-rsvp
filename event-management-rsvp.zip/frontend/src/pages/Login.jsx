import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

export default function Login(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const nav = useNavigate()
  const submit = async (e) => {
    e.preventDefault()
    try {
      const r = await axios.post(import.meta.env.VITE_API_BASE + '/auth/login', { email, password })
      localStorage.setItem('token', r.data.token)
      alert('Logged in')
      nav('/')
    } catch (err) {
      alert(err.response?.data?.error || 'Failed')
    }
  }
  return (
    <form onSubmit={submit} className="max-w-md">
      <h2 className="text-xl mb-3">Login</h2>
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" className="w-full p-2 border mb-2"/>
      <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" className="w-full p-2 border mb-2"/>
      <button className="px-3 py-2 bg-blue-600 text-white rounded">Login</button>
    </form>
  )
}
