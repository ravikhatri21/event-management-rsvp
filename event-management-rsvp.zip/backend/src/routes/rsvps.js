const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');
const nodemailer = require('nodemailer');

// POST /api/events/:id/rsvp
router.post('/events/:id/rsvp', auth, async (req, res) => {
  const eventId = req.params.id;
  const { status } = req.body; // confirmed|pending|declined
  const userId = req.user.id;
  try {
    // check event exists
    const ev = await db.query('SELECT * FROM events WHERE id=$1', [eventId]);
    if (!ev.rows[0]) return res.status(404).json({ error: 'Event not found' });
    const event = ev.rows[0];

    // If confirming, check capacity
    if (status === 'confirmed' && event.capacity > 0) {
      const count = await db.query('SELECT COUNT(*) FROM rsvps WHERE event_id=$1 AND status=$2', [eventId, 'confirmed']);
      if (parseInt(count.rows[0].count) >= event.capacity) {
        return res.status(400).json({ error: 'Event is full' });
      }
    }

    // upsert RSVP
    const up = await db.query(
      `INSERT INTO rsvps (user_id,event_id,status) VALUES ($1,$2,$3)
       ON CONFLICT (user_id,event_id) DO UPDATE SET status=EXCLUDED.status RETURNING *`,
      [userId, eventId, status || 'pending']
    );
    res.json(up.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET attendee list (host only)
router.get('/events/:id/rsvps', auth, async (req, res) => {
  const eventId = req.params.id;
  const ev = await db.query('SELECT * FROM events WHERE id=$1', [eventId]);
  if (!ev.rows[0]) return res.status(404).json({ error: 'Event not found' });
  if (ev.rows[0].host_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  const attendees = await db.query(
    `SELECT r.*, u.name, u.email FROM rsvps r JOIN users u ON r.user_id = u.id WHERE r.event_id=$1 ORDER BY r.created_at ASC`,
    [eventId]
  );
  res.json(attendees.rows);
});

// POST /api/events/:id/reminder  -> send email reminder to confirmed attendees (host only)
router.post('/events/:id/reminder', auth, async (req, res) => {
  const eventId = req.params.id;
  const evr = await db.query('SELECT * FROM events WHERE id=$1', [eventId]);
  if (!evr.rows[0]) return res.status(404).json({ error: 'Event not found' });
  const event = evr.rows[0];
  if (event.host_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });

  const attendees = await db.query(
    `SELECT u.email, u.name FROM rsvps r JOIN users u ON r.user_id=u.id WHERE r.event_id=$1 AND r.status='confirmed'`,
    [eventId]
  );
  if (attendees.rows.length === 0) return res.status(400).json({ error: 'No confirmed attendees' });

  // send email (simple)
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });

  const to = attendees.rows.map(a => a.email).join(',');
  const subject = `Reminder: ${event.title}`;
  const text = `Hi,\n\nThis is a reminder for the event "${event.title}" starting at ${event.starts_at}.\n\nSee you there!`;

  try {
    await transporter.sendMail({
      from: process.env.FROM_EMAIL,
      to,
      subject,
      text
    });
    res.json({ ok: true, sent: attendees.rows.length });
  } catch (err) {
    console.error('Email error', err);
    res.status(500).json({ error: 'Failed to send emails' });
  }
});

module.exports = router;
