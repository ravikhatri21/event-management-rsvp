const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

// list public events (with simple filters)
router.get('/', async (req, res) => {
  try {
    const q = 'SELECT e.*, u.name as host_name FROM events e JOIN users u ON e.host_id = u.id WHERE e.is_public = TRUE ORDER BY e.starts_at ASC LIMIT 100';
    const r = await db.query(q);
    res.json(r.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

router.get('/:id', async (req, res) => {
  const id = req.params.id;
  const r = await db.query('SELECT e.*, u.name as host_name FROM events e JOIN users u ON e.host_id = u.id WHERE e.id=$1', [id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Not found' });
  res.json(r.rows[0]);
});

router.post('/', auth, async (req, res) => {
  try {
    const { title, description, category, location, starts_at, ends_at, capacity, is_public } = req.body;
    if (!title || !starts_at) return res.status(400).json({ error: 'Missing title or starts_at' });
    const r = await db.query(
      `INSERT INTO events (host_id,title,description,category,location,starts_at,ends_at,capacity,is_public)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [req.user.id, title, description, category, location, starts_at, ends_at, capacity || 0, is_public!==false]
    );
    res.json(r.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/:id', auth, async (req, res) => {
  const id = req.params.id;
  // check ownership
  const ev = await db.query('SELECT * FROM events WHERE id=$1', [id]);
  if (!ev.rows[0]) return res.status(404).json({ error: 'Not found' });
  if (ev.rows[0].host_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  const { title, description, category, location, starts_at, ends_at, capacity, is_public } = req.body;
  const r = await db.query(
    `UPDATE events SET title=$1, description=$2, category=$3, location=$4, starts_at=$5, ends_at=$6, capacity=$7, is_public=$8 WHERE id=$9 RETURNING *`,
    [title, description, category, location, starts_at, ends_at, capacity || 0, is_public!==false, id]
  );
  res.json(r.rows[0]);
});

router.delete('/:id', auth, async (req, res) => {
  const id = req.params.id;
  const ev = await db.query('SELECT * FROM events WHERE id=$1', [id]);
  if (!ev.rows[0]) return res.status(404).json({ error: 'Not found' });
  if (ev.rows[0].host_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  await db.query('DELETE FROM events WHERE id=$1', [id]);
  res.json({ ok: true });
});

module.exports = router;
